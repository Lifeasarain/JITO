#-*- coding: utf-8 -*-
from defect_features.config import load_config
conf = load_config.Config()
