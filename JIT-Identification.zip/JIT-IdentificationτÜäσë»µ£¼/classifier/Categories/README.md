This folder contains all the words used to categorize commits. Associated words with commits are expected to be comma-seperated and lower case. 

#需讨论的问题
