
d = {'a':1}
d['b'] = 2
print(d)